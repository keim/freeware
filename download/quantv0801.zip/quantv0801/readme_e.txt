====================================================================
Quantized Blaze ver 0.7.0
  Free Soft for Windows 98/me/2000/XP
  Created by Kei Mesuda (HN; keim)
====================================================================

Thank you for downloading this game.
This game is Free-Soft.

The newest version will be download here.
http://www.yomogi.sakura.ne.jp/~si/ 

[ About this game ]
  This is a fire fighting shotem-up game in Techno-Beat.

[ How to Install ] 
  Unpack zip file. And execute 'qb.exe'.
  If you execute 'window_mode.bat', it executes in a window.

[ How to Uninstall ] 
  Delete all files. This software doesn't rewrite registry files.

[ Required Environment ]
  OS�G WindowsXP (Not Tested; Windows95/98/NT/me/2000)
  CPU; Over PentiumIII 1GHz + OpenGL graphic board

[ Copyright ]
  Copyright 2006 Kei Mesuda All rights reserved. 
  I have no responsibility for your trouble with this game and manual.

[ Special Thanks ]
  Simple Directmedia Layer(SDL) is used in this software.
    SDL(Simple Directmedia Layer) http://www.libsdl.org/
  OpenGL is used for 3D calculation.
    OpenGL ARB                    http://www.opengl.org/

[ Support ] 
  mail; keim@nona.dti.ne.jp
  web;  http://www.yomogi.sakura.ne.jp/~si/SolidImage/index_e.shtml





//----------------------------------------
// Quantized Blaze ver 0.7.0
// Manual
//----------------------------------------
- How to play.
  Play with a Keyboard or Joystick.
  move;    Arrow Keys
  shot;    [Shift] (Joystick Bottun 0)
  bomb;    [Z]     (Joystick Bottun 1)
  restart; [Space] (Joystick Bottun 2)
  exit;    [Esc]�@
  (You can change these setting by rewriting "key.conf".)

- System
  Simply, quench all fire by throwing water (shot).
  When ship is shot by the bullet, OR fire come to the bottom, miss count increase.
  This game has a "TENSION GAUGE" in left-bottom side of the screen.
  Increasing this TENSION, more bonus items are appearing.
  This gauge grow up faster by quenching fire in top of the screen.
  And, when TENSION GAUGE achieve to max, "FEAVER MODE" start.
  In FEAVER MODE, bonus items are absorped automatically.
  In this game, there are 4 stages + 1 boss stage.
  And each stages are classifyed in C, B, A and S.
  If you clear the stage with FEAVER MODE, the class of the next stage will rise.
  
- Key configuration
  You can change key setting by rewriting "key.conf" file.
  Fllowing keywords are enable in "key.conf" file.
    0-9, a-z, "-", "^", "@", "[", ",", ".", "/",
    LEFT�CRIGHT�CUP�CDOWN, (arrow keys)
    LSHIFT�CLCTRL�CLALT�CRSHIFT�CRCTRL�CRALT�C
    PAUSE, ESCAPE, BACKSPACE, TAB, RETURN, SPACE, DELETE, INSERT, HOME, END, PAGEUP, PAGEDOWN, 
    KP0-KP9, KP_PERIOD, KP_DIVIDE, KP_MULTIPLY, KP_PLUS, KP_MINUS, KP_ENTER, KP_EQUALS, (numeric keypad keys)
    F1-F15, NUMLOCK, CAPSLOCK, SCROLLOCK

  If you want to set w-s-a-d moving, n-m-,-. shooting, rewrite "key.conf" file like this.

#SDLKEYCONF_FILE
#VERSION    1.0
#FREERANGE  0.305204
0; XUP = d
0; XDOWN = a
0; YUP = s
0; YDOWN = w
0; BTN0 = n
0; BTN1 = m
0; BTN2 = ,
0; BTN3 = .
0; ESCAPE = ESCAPE  



