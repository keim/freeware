====================================================================
Block Breaker ver 0.8.1
  Free Soft for Windows 98/me/2000/XP
  Created by Kei Mesuda (HN; keim)
====================================================================

Thank you for downloading this game.
This game is Free-Soft.

The newest version will be download here.
http://www.yomogi.sakura.ne.jp/~si/ 

[ About this game ]
  This is a driving game breaking all blocks.

[ How to Install ] 
  Unpack zip file. And execute 'bk.exe'.
  If you execute 'window.bat', it executed in a window.
  If you execute 'edit.bat', it executed in a map editor mode.

[ How to Uninstall ] 
  Delete all files. This software don't rewrite registry files.

[ Required Environment ]
  OS�G WindowsXP (Not Tested; Windows95/98/NT/me/2000)
  CPU; Over PentiumII 600MHz

[ Copyright ]
  Copyright 2005 Kei Mesuda All rights reserved. 
  I have no responsibility for your trouble with this game and manual.

[ Special Thanks ]
  Simple Directmedia Layer(SDL) is used in this software.
    SDL(Simple Directmedia Layer) http://www.libsdl.org/
  OpenGL is used for 3D calculation.
    OpenGL ARB                    http://www.opengl.org/

[ Support ] 
  mail; keim@nona.dti.ne.jp
  web;  http://www.yomogi.sakura.ne.jp/~si/SolidImage/index_e.shtml





//----------------------------------------
// Block Breaker ver 0.8.1
// Manual
//----------------------------------------
- How to play.
  Play with a Keyboard or Joystick.
  Accel;  ArrowUp,[x](Button2)
  Back;   ArrowDown,[z](Button1)
  Turn;   ArrowLeft/Right
  Retry;  [c](Button3)
  Exit;   [Esc]
  (You can change this setting by rewriting "key.conf".)

- System
  Break all blocks in the field by charging.
  
- Key configuration
  You can change key setting by rewriting "key.conf" file.
  Fllowing keywords are enable in "key.conf" file.
    0-9, a-z, "-", "^", "@", "[", ",", ".", "/",
    LEFT�CRIGHT�CUP�CDOWN, (arrow keys)
    LSHIFT�CLCTRL�CLALT�CRSHIFT�CRCTRL�CRALT�C
    PAUSE, ESCAPE, BACKSPACE, TAB, RETURN, SPACE, DELETE, INSERT, HOME, END, PAGEUP, PAGEDOWN, 
    KP0-KP9, KP_PERIOD, KP_DIVIDE, KP_MULTIPLY, KP_PLUS, KP_MINUS, KP_ENTER, KP_EQUALS, (numeric keypad keys)
    F1-F15, NUMLOCK, CAPSLOCK, SCROLLOCK

  If you want to set w-s-a-d moving, v-b-n-m droping and SPACE scrolling, rewrite "key.conf" file like this.

#SDLKEYCONF_FILE
#VERSION    1.0
#FREERANGE  0.305204
0; XUP = d
0; XDOWN = a
0; YUP = s
0; YDOWN = w
0; BTN0 = v
0; BTN1 = b
0; BTN2 = n
0; BTN3 = m
0; BTN4 = SPACE
0; ESCAPE = ESCAPE  



