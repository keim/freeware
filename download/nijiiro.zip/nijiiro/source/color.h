//--------------------------------------------------------------------------------
//	HLS�ϊ� (0<=Hue<192)
//--------------------------------------------------------------------------------
#define HLSA(h, l, s, a) ((((a) & 0xff)<<24) | (((h) & 0xff)<<16) | (((l) & 0xff)<<8) | (s & 0xff))

void RGBAtoHLSA(const DWORD* dwABGR, DWORD* dwAHLS)
{
	//Little Endian
	BYTE* byRGBA = (BYTE*)dwABGR;
	BYTE* bySLHA = (BYTE*)dwAHLS;

	long  lCmax, lCmin;
	long  lCont, lTone2;

	if (byRGBA[0] > byRGBA[1]) {
		lCmin = (byRGBA[1] < byRGBA[2]) ? byRGBA[1] : byRGBA[2];
		lCmax = (byRGBA[0] > byRGBA[2]) ? byRGBA[0] : byRGBA[2];
	} else {
		lCmin = (byRGBA[0] < byRGBA[2]) ? byRGBA[1] : byRGBA[2];
		lCmax = (byRGBA[1] > byRGBA[2]) ? byRGBA[0] : byRGBA[2];
	}
	lTone2 = lCmax + lCmin + 1;
	lCont  = lCmax - lCmin;

	bySLHA[3] = byRGBA[3];				//Alpha
	bySLHA[1] = (BYTE)(lTone2 >> 1);	//Lightness
	if (lCont == 0) {
		bySLHA[0] = 0;					//Saturation
		bySLHA[2] = 0;					//Hue
	} else {
		bySLHA[0] = (bySLHA[1]<128) ? (BYTE)((lCont << 8) / lTone2) : 
									  (BYTE)((lCont << 8) / (512 - lTone2));	//Saturation
		if (byRGBA[0] == lCmax) {
			bySLHA[2] = (BYTE)(((byRGBA[1] - byRGBA[2]) << 5) / lCont);			//Hue
			if (bySLHA[2]<0) bySLHA[2] += 192;
		} else {
			bySLHA[2] = (byRGBA[1] == lCmax) ? (BYTE)(((byRGBA[2] - byRGBA[0]) << 5) / lCont + 64) :	//Hue
											   (BYTE)(((byRGBA[0] - byRGBA[1]) << 5) / lCont + 128);	//Hue
		}
	}
}

void HLSAtoRGBA(const DWORD* dwAHLS, DWORD* dwABGR)
{
	//Little Endian
	BYTE* byRGBA = (BYTE*)dwABGR;
	BYTE* bySLHA = (BYTE*)dwAHLS;

	long lCmin, lCmax, HueSwitch, HueProp;
	long lCont, lTone2;

	byRGBA[3] = bySLHA[3];								//Alpha
	if (bySLHA[0] == 0) {
		byRGBA[0] = byRGBA[1] = byRGBA[2] = bySLHA[1];	//R = G = B = L
	} else {
		lTone2 = bySLHA[1] << 1;
		lCont  = (bySLHA[1] < 128) ? ((lTone2 * bySLHA[0]) >> 8) : (((512 - lTone2) * bySLHA[0]) >> 8);

		lCmin = (lTone2 - lCont) >> 1;
		lCmax = (lTone2 + lCont) >> 1;

		HueSwitch = bySLHA[2] >> 5;
		HueProp   = (lCont * (bySLHA[2] - (HueSwitch << 5))) >> 5;

		switch (HueSwitch) {
		case 0:
			byRGBA[0] = (BYTE)lCmax;
			byRGBA[1] = (BYTE)(lCmin + HueProp);
			byRGBA[2] = (BYTE)lCmin;
			break;
		case 1:
			byRGBA[0] = (BYTE)(lCmax - HueProp);
			byRGBA[1] = (BYTE)lCmax;
			byRGBA[2] = (BYTE)lCmin;
			break;
		case 2:
			byRGBA[0] = (BYTE)lCmin;
			byRGBA[1] = (BYTE)lCmax;
			byRGBA[2] = (BYTE)(lCmin + HueProp);
			break;
		case 3:
			byRGBA[0] = (BYTE)lCmin;
			byRGBA[1] = (BYTE)(lCmax - HueProp);
			byRGBA[2] = (BYTE)lCmax;
			break;
		case 4:
			byRGBA[0] = (BYTE)(lCmin + HueProp);
			byRGBA[1] = (BYTE)lCmin;
			byRGBA[2] = (BYTE)lCmax;
			break;
		case 5:
			byRGBA[0] = (BYTE)lCmax;
			byRGBA[1] = (BYTE)lCmin;
			byRGBA[2] = (BYTE)(lCmax - HueProp);
			break;
		}
	}
}

BYTE RGBtoGRAY(const DWORD* dwABGR)
{
	//Little Endian
	BYTE* byRGBA = (BYTE*)dwABGR;
	return ((byRGBA[0]*77 + byRGBA[1]*150 + byRGBA[2]*29) >> 8);
}