#pragma comment (lib, "winmm.lib")

#include <windows.h>
#include <windowsx.h>
#include <winnls32.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include <float.h>
#include <mmsystem.h>
