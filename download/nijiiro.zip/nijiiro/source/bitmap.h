class CBitmap
{
public:
	BITMAPFILEHEADER	m_bfh;
	BITMAPINFOHEADER	m_bih;
	BYTE*				m_pBits;
	int					m_iWidth32;

public:
	CBitmap()
	{
		SetBMI(&m_bih, &m_bfh, 0, 0, 1);
		m_pBits = NULL;
	}

	CBitmap(const CBitmap &bmp)
	{
		m_pBits = NULL;
		Copy(bmp);
	}

	CBitmap operator = (const CBitmap &bmp)
	{
		Copy(bmp);
		return *this;
	}

	~CBitmap()
	{
		Free();
	}

	BOOL Create(int cx, int cy, DWORD col = 0xffffffff)
	{
		if (!Allocate(cx, cy)) return FALSE;
		if (col != 0xffffffff) ClearMap(col);
		return TRUE;
	}

	void Delete()
	{
		Free();
	}

	void ClearMap(DWORD col)
	{
		int i, j, add, add0;

		col &= 0xffffff;
		int imax = m_bih.biHeight;
		int jmax = m_bih.biWidth;
		BYTE* pBit = m_pBits;
		BYTE* byColor = (BYTE*)(&col);

		for (i=0, add0=0; i<imax; i++, add0+=m_iWidth32) {
			for (j=0, add=add0; j<jmax; j++) {
				pBit[add++] = byColor[0];
				pBit[add++] = byColor[1];
				pBit[add++] = byColor[2];
			}
		}
	}

	BOOL Load(char* strFileName)
	{
		DWORD	iColorCount, iSize;
		RGBQUAD	rgb[256];
		BYTE	*pix = NULL;

		FILE* pFile = fopen(strFileName, "rb");
		if (pFile == NULL) return FALSE;

		Free();
		try {
			//�w�b�_�ǂݍ���
			if (fread(&m_bfh, sizeof(BITMAPFILEHEADER), 1, pFile) != 1)	throw FALSE;
			if (fread(&m_bih, sizeof(BITMAPINFOHEADER), 1, pFile) != 1) throw FALSE;

			switch (m_bih.biBitCount) {
			case 8:
				//�t�@�C���f�[�^�p�ꎞ�̈�̊m��
				iSize = (((m_bih.biWidth+3) >> 2) << 2) * m_bih.biHeight;
				pix = new BYTE[iSize];
				if (pix == NULL) throw FALSE;
				iColorCount = (m_bfh.bfOffBits - (sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER))) / 4;
				if (iColorCount < 2 || iColorCount > 256) iColorCount = 256;

				//�f�[�^�ǂݍ���
				if (fread(rgb, sizeof(RGBQUAD), iColorCount, pFile) != iColorCount) throw FALSE;
				if (fread(pix, sizeof(BYTE), iSize, pFile) != iSize) throw FALSE;

				//24Bit�ɕϊ�
				if (!Allocate(m_bih.biWidth, m_bih.biHeight)) throw FALSE;
				if (!Trans8to24(pix, m_bih.biWidth, m_bih.biHeight, rgb)) throw FALSE;
				break;
			case 24:
				//�̈�m�ہC�t�@�C���ǂݍ���
				if (!Allocate(m_bih.biWidth, m_bih.biHeight)) throw FALSE;
				if (fread(m_pBits, sizeof(BYTE), m_bih.biSizeImage, pFile) != m_bih.biSizeImage) throw FALSE;
				break;
			default:
				throw FALSE;
			}

			throw TRUE;
		}

		catch(BOOL return_value)
		{
			fclose(pFile);
			if (pix != NULL) delete[] pix;
			return return_value;
		}
	}

	BOOL Stretch(int cx, int cy)
	{
		int i, j, addOrg, add;
		double x, y;
		double xdpp = (double)m_bih.biWidth / (double)cx;
		double ydpp = (double)m_bih.biHeight / (double)cy;
		BYTE* pix = new BYTE[m_bih.biSizeImage];
		if (m_pBits == NULL) return FALSE;
		memcpy(pix, m_pBits, m_bih.biSizeImage);
		int pixw = m_iWidth32;
		int pixh = m_bih.biHeight;

		try {
			Free();
			if (!Allocate(cx, cy)) throw FALSE;
			for (i=0, y=0; i<cy; i++, y+=ydpp) {
				add = m_bih.biSizeImage - (i+1)*m_iWidth32;
				for (j=0, x=0; j<cx; j++, x+=xdpp) {
					addOrg = pixw * (pixh - ((int)y) - 1) + ((int)x) * 3;
					m_pBits[add++] = pix[addOrg++];
					m_pBits[add++] = pix[addOrg++];
					m_pBits[add++] = pix[addOrg];
				}
			}
			throw TRUE;
		}

		catch (BOOL return_value) {
			delete[] pix;
			return return_value;
		}
	}

	int CalcAddress(int x, int y)
	{
		return m_iWidth32 * (m_bih.biHeight - y - 1) + x * 3;
	}

protected:
	BOOL Allocate(int cx , int cy)
	{
		m_iWidth32 = SetBMI(&m_bih, &m_bfh, cx, cy, 24);

		m_pBits = new BYTE[m_bih.biSizeImage];
		if (m_pBits == NULL) return FALSE;

		return TRUE;
	}

	void Free()
	{
		if (m_pBits != NULL) delete[] m_pBits;
		SetBMI(&m_bih, &m_bfh, 0, 0, 1);
	}

	BOOL Copy(const CBitmap &bmp)
	{
		Free();
		m_bfh = bmp.m_bfh;
		m_bih = bmp.m_bih;
		if (!Allocate(bmp.m_bih.biWidth, bmp.m_bih.biHeight)) return FALSE;
		m_iWidth32 = bmp.m_iWidth32;
		memcpy(m_pBits, bmp.m_pBits, m_bih.biSizeImage);

		return TRUE;
	}

	BOOL Trans8to24(BYTE* pix, int w, int h, RGBQUAD* rgb)
	{
		int i, j, add, addBits;
		int spBits = (((w*3+3) >> 2) << 2) - w*3;
		int sp     = (((w+3) >> 2) << 2) - w;

		if (m_pBits == NULL) if (!Allocate(w, h)) return FALSE;

		for (i=0, add=0, addBits=0; i<h; i++) {
			for (j=0; j<w; j++) {
				m_pBits[addBits]   = rgb[pix[add]].rgbBlue;
				m_pBits[addBits+1] = rgb[pix[add]].rgbGreen;
				m_pBits[addBits+2] = rgb[pix[add]].rgbRed;
				add++;
				addBits+=3;
			}
			add += sp;
			addBits += spBits;
		}

		return TRUE;
	}
};