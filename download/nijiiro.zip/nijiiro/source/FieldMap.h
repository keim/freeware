// �z���Z���s�����߂̋��p��
union unByteChar {
    BYTE by;
    char ch;
};

// �}�b�v��ID
#define ID_VOID             0           // ���
#define ID_WALL             1           // ��
#define CHECK_BEAD(map)     ((map)>1)   // �����ɗ��������TRUE

// �t�B�[���h�}�b�v�N���X
class CFieldMap : public ICanDraw
{
private:
    SIZE    m_szField;              // �t�B�[���h�T�C�Y

    // �t�B�[���h�}�b�v
    int     m_iMemorySize;          // �������T�C�Y
    BYTE*   m_HMap[2];              // Hue �}�b�v
    BYTE*   m_SMap[2];              // Satuation �}�b�v

    int     m_iFlipMapSwitch;       // �X�N���[���ɓ]������}�b�v�̔ԍ�
    int     m_addBitsStart[4];      // �`��̍ۂ̊J�n�A�h���X

    // �F�r�[�Y�p�^�[��
    DWORD   m_dwColor[128][6][15];  // RGB Color[Hue][Sat][ScanLine]
    int     m_iLightnessTune;       // ���邳�␳�l
    int     m_iHueTune[6];          // �F���␳�l

    // �������p
    BOOL    m_bMouthOpen;           // �������t���O
    POINT   m_ptMouthPos;           // �����ʒu
    POINT   m_ptAimsTo;             // �J�[�\����������
    int     m_iAppBeadMax;          // ��������r�[�Y�̐�
    int     m_iAppBeadCount;        // �������̃r�[�Y�̐�
    int     m_iBeadHue;             // �������̃r�[�Y�̐F

    // ���F�p
    int     m_iMixFrame;            // ���F���P����i�ރt���[����
    int     m_iMixCount;            // m_iMixCount�p�J�E���^

    // �����_�\����
    struct strRAINBOWPOINT{
        int     address;
        int     count;
    } m_RainbowPoint[RAINBOWPOINT_MAX];
    int     m_iRainbowPointCount;

public:
    CFieldMap()
    {
        m_HMap[0] = NULL;
        m_HMap[1] = NULL;
        m_SMap[0] = NULL;
        m_SMap[1] = NULL;
    }

    ~CFieldMap()
    {
        // ���������
        Free();
    }

    // ������
    BOOL Init()
    {
        int i;

        ClearMap();
        
        // �p�����[�^������
        m_iFlipMapSwitch = 0;
        m_ptMouthPos.x = 0;
        m_ptMouthPos.y = 0;
        m_ptAimsTo.x = m_szField.cx / 2;
        m_ptAimsTo.y = m_szField.cy / 2;
        m_bMouthOpen = FALSE;
        m_iAppBeadCount = 0;
        m_iBeadHue = 0;
        m_iAppBeadMax = 100;

        m_iMixFrame = COLORMIX_FRAME;
        m_iMixCount = 0;

        for (i=0; i<RAINBOWPOINT_MAX; i++) {
            m_RainbowPoint[i].address = -1;
            m_RainbowPoint[i].count = -1;
        }

        // �F���␳�l
        m_iLightnessTune = HUETUNE_BASE;
        m_iHueTune[0] = HUETUNE_B;
        m_iHueTune[1] = HUETUNE_C;
        m_iHueTune[2] = HUETUNE_G;
        m_iHueTune[3] = HUETUNE_Y;
        m_iHueTune[4] = HUETUNE_R;
        m_iHueTune[5] = HUETUNE_M;

        // �F�v�Z
        CalcColorBeads();

        return TRUE;
    }

    // �`��ʒu�ݒ�i�I�[�o�[���C�h�j
    void SetPosition(int x0, int y0)
    {
        m_ptOrigin.x = x0;
        m_ptOrigin.y = y0;
        m_addBitsStart[0] = CalcAddress(0, 0);
        m_addBitsStart[1] = m_addBitsStart[0] - m_iScreenWidth;
        m_addBitsStart[2] = m_addBitsStart[1] - m_iScreenWidth;
        m_addBitsStart[3] = m_addBitsStart[2] - m_iScreenWidth;
    }

    // 1�t���[�����s
    BOOL Run()
    {
        // �J�[�\��
        MoveCursor();
        if (m_bMouthOpen) m_bMouthOpen = Appear();

        MoveBead();         // ����
        MixBead();          // ���F
        ReactionBead();     // ����

        return TRUE;
    }

    // �`��i�I�[�o�[���C�h�j
    void Draw()
    {
        TransToScreen();
    }

    // ������
    BOOL FloodBead(int Hue, int Count)
    {
        if (m_bMouthOpen) return FALSE;

        m_bMouthOpen = TRUE;
        m_iAppBeadCount = 0;
        m_iAppBeadMax = Count;
        m_iBeadHue = Hue;

        return TRUE;
    }

    int GetReactionPoint()
    {
        return m_iRainbowPointCount;
    }

    // �J�[�\���ʒu�ݒ�
    void CalcCursor(int x, int y)
    {
        m_ptAimsTo.x = (x - m_ptOrigin.x) >> 2;
        m_ptAimsTo.y = (y - m_ptOrigin.y) >> 2;
        m_ptAimsTo.x = __min(m_szField.cx-8, __max(8, m_ptAimsTo.x));
        m_ptAimsTo.y = __min(m_szField.cy-10, __max(10, m_ptAimsTo.y));
    }

    // �J�[�\���`��
    void DrawCursor(HDC hDC, int Hue)
    {
        BYTE* pcol = (BYTE*)&(m_dwColor[Hue][5][3]);
        DWORD col = (pcol[0]<<16) | (pcol[1]<<8) | (pcol[2]);
        POINT pt;

        pt.x = (m_ptMouthPos.x<<2) + m_ptOrigin.x;
        pt.y = (m_ptMouthPos.y<<2) + m_ptOrigin.y;
        DrawFrameRect(hDC, pt.x-24, pt.y-24, 53, 53, 0x808080);
        DrawRect     (hDC, pt.x-6,  pt.y-6, 17, 17, col);
    }

    // �������m��
    BOOL Allocate(int cx, int cy)
    {
        Free();

        m_szField.cx = cx;
        m_szField.cy = cy;
        m_iMemorySize = (cx+4) * (cy+4);

        m_HMap[0] = new BYTE[m_iMemorySize];
        m_HMap[1] = new BYTE[m_iMemorySize];
        m_SMap[0] = new BYTE[m_iMemorySize];
        m_SMap[1] = new BYTE[m_iMemorySize];
        if (m_HMap[0] == NULL || m_HMap[1] == NULL || m_SMap[0] == NULL || m_SMap[1] == NULL) return FALSE;

        ClearMap();

        return TRUE;
    }

private:
    // ���������
    void Free()
    {
        m_szField.cx = 0;
        m_szField.cy = 0;
        m_iMemorySize = 0;

        if (m_HMap[0] == NULL) delete[] m_HMap[0];
        if (m_HMap[1] == NULL) delete[] m_HMap[1];
        if (m_SMap[0] == NULL) delete[] m_SMap[0];
        if (m_SMap[1] == NULL) delete[] m_SMap[1];
    }

    // �}�b�v�������iAllocate()������Ăяo���j
    void ClearMap()
    {
        int  iFieldWidth = m_szField.cx+4;
        int  iFieldHeight = m_szField.cy+4;
        int  i;

        // field
        memset(m_HMap[0], 0, m_iMemorySize);
        memset(m_HMap[1], 0, m_iMemorySize);
        memset(m_SMap[0], ID_VOID, m_iMemorySize);
        memset(m_SMap[1], ID_VOID, m_iMemorySize);

        // side wall
        for (i=0; i<iFieldWidth; i++) {
            m_SMap[0][i] = 
            m_SMap[1][i] = 
            m_SMap[0][iFieldWidth + i] = 
            m_SMap[1][iFieldWidth + i] = 
            m_SMap[0][iFieldWidth * (iFieldHeight-2) + i] = 
            m_SMap[1][iFieldWidth * (iFieldHeight-2) + i] = 
            m_SMap[0][iFieldWidth * (iFieldHeight-1) + i] = 
            m_SMap[1][iFieldWidth * (iFieldHeight-1) + i] = ID_WALL;
        }
        for (i=0; i<iFieldHeight; i++) {
            m_SMap[0][iFieldWidth * i] = 
            m_SMap[1][iFieldWidth * i] = 
            m_SMap[0][iFieldWidth * i + 1] = 
            m_SMap[1][iFieldWidth * i + 1] = 
            m_SMap[0][iFieldWidth * (i+1) - 2] = 
            m_SMap[1][iFieldWidth * (i+1) - 2] = 
            m_SMap[0][iFieldWidth * (i+1) - 1] = 
            m_SMap[1][iFieldWidth * (i+1) - 1] = ID_WALL;
        }
    }

    // �F�r�[�Y�p�^�[���̍쐬
    void CalcColorBeads()
    {
        int s, h, l, i, j, Lightness;
        DWORD   dwAHLS[4];
        DWORD   dwABGR[4];
        short   Bead[20] = { 64,   8,  16,  48, 
                              8, 255,   0, -16, 
                             16,   0,   0, -32, 
                             48, -16, -32,  32,     // �r�[�Y�̖��x�}�b�v
                             16,  16,  16,  16};    // �l�p�\���p

        // �F�v�Z
        for (h=0; h<128; h++) {
            for (i=0; i<15; i++) {
                m_dwColor[h][ID_WALL][i] = 0x80808080;  // �ǐF
                m_dwColor[h][ID_VOID][i] = 0xffffffff;  // �w�i�F
            }
            for (s=0; s<4; s++) {
                // ���邳�␳
                Lightness = 128 + m_iLightnessTune;
                Lightness += (abs(h-64)  > 42) ? ((abs(h-64)-42) *6*m_iHueTune[0]/100) : 0;     // Blue
                Lightness += (abs(h-21)  < 22) ? ((22-abs(h-21)) *6*m_iHueTune[1]/100) : 0;     // Cyan
                Lightness += (abs(h-42)  < 22) ? ((22-abs(h-42)) *6*m_iHueTune[2]/100) : 0;     // Green
                Lightness += (abs(h-64)  < 22) ? ((22-abs(h-64)) *6*m_iHueTune[3]/100) : 0;     // Yellow
                Lightness += (abs(h-85)  < 22) ? ((22-abs(h-85)) *6*m_iHueTune[4]/100) : 0;     // Red
                Lightness += (abs(h-107) < 22) ? ((22-abs(h-107))*6*m_iHueTune[5]/100) : 0;     // Magenta
                for (j=0; j<5; j++) { 
                    for (i=0; i<4; i++) { 
                        l = __max(0, __min(255, Lightness + Bead[j*4+i]+s*8));  // ���x�v�Z
                        dwAHLS[i] = HLSA(h*192/128, l, 255-s*8, 0);             // HLS�ϊ�
                        HLSAtoRGBA(&dwAHLS[i], &dwABGR[i]);
                    }
                    m_dwColor[h][s+2][j*3]   = ((dwABGR[1] << 24) & 0xff000000) | ((dwABGR[0])       & 0x00ffffff); // RBGR
                    m_dwColor[h][s+2][j*3+1] = ((dwABGR[2] << 16) & 0xffff0000) | ((dwABGR[1] >> 8)  & 0x0000ffff); // GRBG
                    m_dwColor[h][s+2][j*3+2] = ((dwABGR[3] << 8)  & 0xffffff00) | ((dwABGR[2] >> 16) & 0x000000ff); // BGRB
                }
            }
        }
    }

// Run
    // ������
    BOOL Appear()
    {
        static const WORD BeadShape[16] = {0x07e0, 0x1ff8, 0x3ffc, 0x7ffe, 0x7ffe, 0xffff, 0xffff, 0xffff, 
                                           0xffff, 0xffff, 0xffff, 0x7ffe, 0x7ffe, 0x3ffc, 0x1ff8, 0x07e0};
        int x, y, add;

        BYTE *HMap = m_HMap[1-m_iFlipMapSwitch];
        BYTE *SMap = m_SMap[1-m_iFlipMapSwitch];
        WORD buf;

        add = (m_ptMouthPos.y-8) * (m_szField.cx+4) + m_ptMouthPos.x - 8 + 2;
        for (y=0; y<16; y++, add+=m_szField.cx+4-16) {
            buf=BeadShape[y];
            for (x=0; x<16; x++, add++, buf>>=1) {
                if ((buf & 1) && SMap[add]==ID_VOID) {
                    HMap[add] = m_iBeadHue;
                    SMap[add] = (BYTE)(randMT() & 3) + 2;
                    if (++m_iAppBeadCount >= m_iAppBeadMax) return FALSE;
                }
            }
        }
        return TRUE;
    }

    // �J�[�\���ړ�
    void MoveCursor()
    {
        m_ptMouthPos = m_ptAimsTo;
    }

    // ���ړ�
    void MoveBead()
    {
        static const int  iFieldWidth = m_szField.cx+4;
        static const int  iFieldHeight = m_szField.cy+4;
        static const int  cx2 = iFieldWidth << 1;
        static const int  cx3 = cx2 + iFieldWidth;
        // ���̐^�����󔒂������ꍇ�C
        // �f���ɗ����邩�C���E����̊��荞�݂��D�悳��邩
        // �����ɂ���Č��肷�邽�߂̃e�[�u��
        // �i0=���������C1=�E���犊�荞�݁C2=�����犊�荞�݁j
        static const BYTE fall_table[32] = {0, 0, 0, 0, 0, 0, 0, 0,     // ���荞�߂鍻�����Ȃ��ꍇ�C���������̊m��8/8
                                            0, 0, 0, 1, 1, 1, 1, 1,     // �E���犊�荞�݂̊m��5/8�C���������̊m��3/8
                                            0, 0, 0, 2, 2, 2, 2, 2,     // �����犊�荞�݂̊m��5/8�C���������̊m��3/8
                                            0, 0, 1, 1, 1, 2, 2, 2};    // ���E���犊�荞�݂̊m���e3/8�C���������̊m��2/8

        int  x, y, add;
        BYTE fall_sw;
        BYTE *HRef = m_HMap[1-m_iFlipMapSwitch];
        BYTE *SRef = m_SMap[1-m_iFlipMapSwitch];

        // �ړ�
        for (y=m_szField.cy-1, add=(iFieldHeight-3)*iFieldWidth-3; y!=0; y--, add-=4) {
            for (x=m_szField.cx; x!=0; x--, add--) {

                if (CHECK_BEAD(SRef[add])) {
                    // ������
                    if (SRef[add+iFieldWidth]==ID_VOID) {
                        if (SRef[add+cx2]==ID_VOID) {
                            if (SRef[add+cx3]==ID_VOID) {
                                // �R��������
                                HRef[add+cx3] = HRef[add];
                                SRef[add+cx3] = SRef[add];
                            } else {
                                // �Q��������
                                HRef[add+cx2] = HRef[add];
                                SRef[add+cx2] = SRef[add];
                            }
                            SRef[add] = ID_VOID;
                            continue;
                        }
                        // �E(bit3)/��(bit4)���犊�荞�މ\���̂��鍻�����݂��邩�C����3bit�͗���
                        fall_sw = ((CHECK_BEAD(SRef[add+iFieldWidth+1]) && CHECK_BEAD(SRef[add+1])) ? 8 : 0) | 
                                  ((CHECK_BEAD(SRef[add+iFieldWidth-1]) && CHECK_BEAD(SRef[add-1])) ? 16 : 0) |
                                  (BYTE)(randMT() & 7);

                        if (fall_table[fall_sw]==0) {
                            // ���������̏ꍇ
                            HRef[add+iFieldWidth] = HRef[add];
                            SRef[add+iFieldWidth] = SRef[add];
                            SRef[add] = ID_VOID;
                            continue;
                        }

                        // ���E����̊��荞�݂��D�悳���ꍇ�́C
                        // ���������ł��Ȃ��������͍������E���Ɋ��荞�߂邽�߁C
                        // ���������̏ꍇ�ƈقȂ�Ccontinue�͂��Ȃ��D
                        switch (fall_table[fall_sw]) {
                        case 1:
                            // �E���犊�荞��
                            HRef[add+iFieldWidth] = HRef[add+1];
                            SRef[add+iFieldWidth] = SRef[add+1];
                            SRef[add+1] = ID_VOID;
                            break;
                        case 2:
                            // �����犊�荞��
                            HRef[add+iFieldWidth] = HRef[add-1];
                            SRef[add+iFieldWidth] = SRef[add-1];
                            SRef[add-1] = ID_VOID;
                            break;
                        }
                    }
                    // �����Ɉړ�
                    if (SRef[add+iFieldWidth+1]==ID_VOID) {
                        HRef[add+iFieldWidth+1] = HRef[add];
                        SRef[add+iFieldWidth+1] = SRef[add];
                        SRef[add] = ID_VOID;
                        continue;
                    }
                    // �E���Ɉړ�
                    if (SRef[add+iFieldWidth-1]==ID_VOID && SRef[add-1]==ID_VOID) {
                        HRef[add+iFieldWidth-1] = HRef[add];
                        SRef[add+iFieldWidth-1] = SRef[add];
                        SRef[add] = ID_VOID;
                        continue;
                    }
                }
            }
        }
    }

    // ���F
    void MixBead()
    {
        // m_iMixFrame���ɍ��F�C����ȊO�͍��F����
        if (++m_iMixCount < m_iMixFrame) {
            NoMixBead();
            return;
        }   
        m_iMixCount = 0;

        static const int  iFieldWidth = m_szField.cx+4;
        static const int  iFieldHeight = m_szField.cy+4;

        int x, y, add, dH, NearBeadCount;
        BYTE *HRef = m_HMap[1-m_iFlipMapSwitch];
        BYTE *SRef = m_SMap[1-m_iFlipMapSwitch];
        BYTE *HCur = m_HMap[m_iFlipMapSwitch];
        BYTE *SCur = m_SMap[m_iFlipMapSwitch];
        unByteChar WrapAround64v, WrapAround64h;        // -64�`+63�ŏz���Z���s�����߂̋��p��

        for (y=m_szField.cy, add=(iFieldHeight-2)*iFieldWidth-3; y!=0; y--, add-=4) {
            for (x=m_szField.cx; x!=0; x--, add--) {
                SCur[add] = SRef[add];
                HCur[add] = HRef[add];

                // ���F�v�Z
                if (CHECK_BEAD(SRef[add])) {
                    // ���ӂƂ̐F�����̌v�Z
                    dH = 0;                 // �F�����i�̓�{�j�̍��v
                    NearBeadCount = 0;      // ����̗���
                    // �E
                    if (CHECK_BEAD(SRef[add+1])) {
                        NearBeadCount++;
                        WrapAround64h.by = (HRef[add+1] - HRef[add]) << 1;
                        dH += WrapAround64h.ch;
                        // 2�E
                        if (CHECK_BEAD(SRef[add+2])) {
                            WrapAround64h.by = (HRef[add+2] - HRef[add]) << 1;
                            dH += WrapAround64h.ch;
                        }
                    }
                    // ��
                    if (CHECK_BEAD(SRef[add-1])) {
                        NearBeadCount++;
                        WrapAround64h.by = (HRef[add-1] - HRef[add]) << 1;
                        dH += WrapAround64h.ch;
                        // 2��
                        if (CHECK_BEAD(SRef[add-2])) {
                            WrapAround64h.by = (HRef[add-2] - HRef[add]) << 1;
                            dH += WrapAround64h.ch;
                        }
                    }
                    // ��
                    if (CHECK_BEAD(SRef[add+iFieldWidth])) {
                        NearBeadCount++;
                        WrapAround64v.by = (HRef[add+iFieldWidth] - HRef[add]) << 1;
                        dH += WrapAround64v.ch;
                    }
                    // ��
                    if (CHECK_BEAD(SRef[add-iFieldWidth])) {
                        NearBeadCount++;
                        WrapAround64v.by = (HRef[add-iFieldWidth] - HRef[add]) << 1;
                        dH += WrapAround64v.ch;
                    }

                    // (�F�����̓�{) < 6 �ŕ��t���
                    if (abs(dH) < 6) {
                        // ���t��ԂŎl���͂܂�Ă�������ٓ_����
                        if (NearBeadCount == 4) {
                            WrapAround64h.by = (HRef[add+1] - HRef[add-1]) << 1;                            // ���F����
                            WrapAround64v.by = (HRef[add+iFieldWidth] - HRef[add-iFieldWidth]) << 1;        // �c�F����
                            if (abs(WrapAround64h.ch) > 32 && abs(WrapAround64v.ch) > 64) {
                                RegisterPoint(add);     // �㉺���E�̐F���������l�ȏ�Ȃ甽��
                            }
                        }
                    } else {
                        // �F���������炷�����ɕϐF
                        HCur[add] += (dH<0) ? -1 : 1;
                        HCur[add] &= 0x7f;
                    }
                }
            }
        }
    }

    void NoMixBead()
    {
        // ���F�����D�R�s�[�̂�
        memcpy(m_HMap[m_iFlipMapSwitch], m_HMap[1-m_iFlipMapSwitch], m_iMemorySize);
        memcpy(m_SMap[m_iFlipMapSwitch], m_SMap[1-m_iFlipMapSwitch], m_iMemorySize);
    }

    // ����
    void ReactionBead()
    {
        int i;
        BYTE *SCur = m_SMap[m_iFlipMapSwitch];

        // 1�t���[���̔����ɂ���ď����鍻�̏������̃e�[�u��
        // (bit2) == 1 �̏ꍇ�C�����_���ЂƂ��Ɉړ�����D
        // �i����2bit�ɂ��āC0=1������C1=2������C2=4������C3=6������j
        static const BYTE reaction_table[16] = {4, 5, 2, 7, 2, 2, 2, 1, 1, 1, 5, 0, 0, 0, 0, 0};

        m_iRainbowPointCount = 0;
        for (i=0; i<RAINBOWPOINT_MAX; i++) {
            if (m_RainbowPoint[i].count != -1) {
                // ������
                m_iRainbowPointCount++;
                switch (reaction_table[m_RainbowPoint[i].count] & 3) {
                case 3:
                    SCur[m_RainbowPoint[i].address-1] = ID_VOID;
                    SCur[m_RainbowPoint[i].address+m_szField.cx+3] = ID_VOID;
                case 2:
                    SCur[m_RainbowPoint[i].address+1] = ID_VOID;
                    SCur[m_RainbowPoint[i].address+m_szField.cx+5] = ID_VOID;
                case 1:
                    SCur[m_RainbowPoint[i].address+m_szField.cx+4] = ID_VOID;
                case 0:
                    SCur[m_RainbowPoint[i].address] = ID_VOID;
                    break;
                }
                // �����_���ЂƂ��Ɉړ�
                if (reaction_table[m_RainbowPoint[i].count] & 4) {
                    m_RainbowPoint[i].address += m_szField.cx+4;
                    if (m_RainbowPoint[i].address >= m_iMemorySize) m_RainbowPoint[i].count = 0;
                }
                m_RainbowPoint[i].count--;
            }
        }
    }

    // �����_�̓o�^
    void RegisterPoint(int address)
    {
        int i;
        
        // ���ɓ��������_������ꍇ�C�J�E���^�����Z�b�g
        for (i=0; i<RAINBOWPOINT_MAX; i++) {
            if (m_RainbowPoint[i].address == address) {
                m_RainbowPoint[i].count = 16;
                return;
            }
        }

        // ������΁C�����_��V���ɓo�^
        for (i=0; i<RAINBOWPOINT_MAX; i++) {
            if (m_RainbowPoint[i].count == -1) {
                m_RainbowPoint[i].address = address;
                m_RainbowPoint[i].count = 16;
                return;
            }
        }
    }

// Draw
    // �}�b�v�f�[�^���X�N���[���ɕ`��
    // 4�{�`��
    void TransToScreen()
    {
        int     i, j;
        DWORD   *pdwRGB;
        DWORD   *pdwBits1, *pdwBits2, *pdwBits3, *pdwBits4;

        BYTE    *Bits = m_pBits;
        BYTE    *HMap = m_HMap[m_iFlipMapSwitch];
        BYTE    *SMap = m_SMap[m_iFlipMapSwitch];

        int     imax = m_szField.cy;
        int     jmax = (m_szField.cx << 1) + m_szField.cx;  // m_szField.cx * 3

        int     addBits1 = m_addBitsStart[0];           // �P�s�ړ]����A�h���X
        int     addBits2 = m_addBitsStart[1];           // �Q�s�ړ]����A�h���X
        int     addBits3 = m_addBitsStart[2];           // �R�s�ړ]����A�h���X
        int     addBits4 = m_addBitsStart[3];           // �S�s�ړ]����A�h���X
        int     addBitsInc = - (m_iScreenWidth << 2);   // �P���C�����Ɉړ�����ۂ́C�]����A�h���X�W�����v��
        int     add = ((m_szField.cx+4) << 1) + 2;      // �]�����A�h���X

        // 4�{�g��
        // BYTE[3]={R1,G1,B1} �� DWORD[3]={R1G1B1R1,G1B1R1G1,B1R1G1B1} 
        // �󔒂͕`�悵�Ȃ����߁Ccontinue
        for (i=0; i<imax; i++, add+=4) {
            pdwBits1 = (DWORD*)(&Bits[addBits1]);
            pdwBits2 = (DWORD*)(&Bits[addBits2]);
            pdwBits3 = (DWORD*)(&Bits[addBits3]);
            pdwBits4 = (DWORD*)(&Bits[addBits4]);
            for (j=0; j<jmax;) {
                if (SMap[add] == ID_VOID) {
                    add++;
                    j+=3;
                    continue;
                }
                pdwRGB = m_dwColor[HMap[add]][SMap[add]];
                add++;

                pdwBits1[j] = pdwRGB[0];
                pdwBits2[j] = pdwRGB[3];
                pdwBits3[j] = pdwRGB[6];
                pdwBits4[j] = pdwRGB[9];
                j++;
                pdwBits1[j] = pdwRGB[1];
                pdwBits2[j] = pdwRGB[4];
                pdwBits3[j] = pdwRGB[7];
                pdwBits4[j] = pdwRGB[10];
                j++;
                pdwBits1[j] = pdwRGB[2];
                pdwBits2[j] = pdwRGB[5];
                pdwBits3[j] = pdwRGB[8];
                pdwBits4[j] = pdwRGB[11];
                j++;
            }
            addBits1 += addBitsInc;
            addBits2 += addBitsInc;
            addBits3 += addBitsInc;
            addBits4 += addBitsInc;
        }

        m_iFlipMapSwitch = 1-m_iFlipMapSwitch;
    }
};

// ���_�Ǘ�
class CScoreManager
{
private:
    int     m_iScore;
    int     m_iBonus;
    int     m_iReactionPointCount;
    int     m_iCounter;
    bool    m_bGameOver;

    HFONT   m_hFont;

public:
    CScoreManager()
    {
        m_hFont = NULL;
        Init();
    }

    ~CScoreManager()
    {
        if (m_hFont != NULL) DeleteObject(m_hFont);
    }

    void Init()
    {
        m_iScore = 0;
        m_iBonus = 0;
        m_iReactionPointCount = 0;
        m_iCounter = 0;
        m_bGameOver = false;

        LOGFONT lf;
        SetLogFont(&lf, "Terminal", 16);
        m_hFont = CreateFontIndirect(&lf);
    }

    void Bonus(int iRactPoint)
    {
        if (!m_bGameOver) {

            m_iReactionPointCount = iRactPoint;

            if (m_iReactionPointCount > 0) {
                m_iScore += ((m_iBonus / 60) + 1) * m_iReactionPointCount;
                m_iBonus += (m_iBonus >= 1170) ? 0 : 1;
                m_iCounter = 44;
            }

            m_iCounter--;
            if (m_iCounter <= 0) {
                m_iBonus = 0;
                m_iCounter = 0;
            }

        }
    }

    void GameOver()
    {
        m_bGameOver = true;
    }

    bool IsGameOver()
    {
        return m_bGameOver;
    }

    void Draw(HDC hDC)
    {
        char str[32];

        SelectObject(hDC, m_hFont);

        sprintf(str, "SCORE: % 10d ", m_iScore);
        TextOut(hDC, 0, 0, str, 18);

        if (m_iCounter > 0) {
            sprintf(str, "BONUS: % 2d x % 2d     ", ((m_iBonus / 60) + 1), m_iReactionPointCount);
            TextOut(hDC, 0, 16, str, strlen(str));
        } else {
            TextOut(hDC, 0, 16, "BONUS:  0 x  0     ", 18);
        }

        if (m_bGameOver) {
            strcpy(str, " G A M E  O V E R ");
            TextOut(hDC, 0, 200, str, strlen(str));
            strcpy(str, "L-Click to Restart");
            TextOut(hDC, 0, 220, str, strlen(str));
            sprintf(str, "SCORE: % 10d ", m_iScore);
            TextOut(hDC, 0, 280, str, strlen(str));
        }
    }
};

// �C���[�W�Ǘ�
class CBackSurface : public ICanDraw
{
private:
    CBitmap m_MemorySurface;
    int     m_surf_add;
    SIZE    m_surf_size;

public:
    CBackSurface()
    {
        m_surf_add = 0;
        m_surf_size.cx = m_surf_size.cy = 0;
    }

    BOOL LoadSurface(char *strFileName)
    {
        m_MemorySurface.Delete();
        return m_MemorySurface.Load(strFileName);
    }

    void SetTexturePosition(int x, int y, int cx, int cy)
    {
        m_surf_add = m_MemorySurface.CalcAddress(x, y);
        m_surf_size.cx = cx;
        m_surf_size.cy = cy;
    }

    BOOL Stretch(int cx, int cy)
    {
        return m_MemorySurface.Stretch(cx, cy);
    }

    void Draw()
    {
        int     i;
        int     size = m_surf_size.cx * 3;
        int     imax = m_surf_size.cy;
        int     screen_add = CalcAddress(0, 0);
        int     surface_add = m_surf_add;
        int     screen_inc = m_iScreenWidth;
        int     surface_inc = m_MemorySurface.m_iWidth32;
        BYTE*   pScreen = m_pBits;
        BYTE*   pSurface = m_MemorySurface.m_pBits;

        for (i=0; i<imax; i++) {
            memcpy(&(pScreen[screen_add]), &(pSurface[surface_add]), size);
            screen_add -= screen_inc;
            surface_add -= surface_inc;
        }
    }
};
