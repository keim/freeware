====================================================================
Speed Shooter ver 0.9.2
  Free Soft for Windows 98/me/2000/XP
  Created by Kei Mesuda (HN; keim)
====================================================================

Thank you for downloading this game.
This game is Free-Soft.

The newest version will be download here.
http://www.yomogi.sakura.ne.jp/~si/ 

[ About this game ]
  This is Puzzle Action Game.

[ How to Install ] 
  Unpack zip file. And execute 'ss.exe'.
  If you execute 'window_mode.bat', it executed in a window.

[ How to Uninstall ] 
  Delete all files. This software don't rewrite registry files.

[ Required Environment ]
  OS�G WindowsXP (Not Tested; Windows95/98/NT/me/2000)
  CPU; Over PentiumIII 600MHz

[ Copyright ]
  Copyright 2005 Kei Mesuda All rights reserved. 
  I have no responsibility for your trouble with this game and manual.

[ Special Thanks ]
  Simple Directmedia Layer(SDL) is used in this software.
    SDL(Simple Directmedia Layer) http://www.libsdl.org/
  OpenGL is used for 3D calculation.
    OpenGL ARB                    http://www.opengl.org/
  SDL_mixer are used for sound system.
    SDL_mixer 1.2                 http://www.libsdl.org/projects/SDL_mixer/
   
[ Support ] 
  mail; keim@nona.dti.ne.jp
  web;  http://www.yomogi.sakura.ne.jp/~si/SolidImage/index_e.shtml





//----------------------------------------
// Speed Shooter ver 0.9.1
// Manual
//----------------------------------------
- How to play.
  Play with a Keyboard or Joystick.
  Move cursor;  Arrow Key
  Throw card into the field;  [Z]/[X]/[C]/[V]
  Scroll quickly; [Shift](Left)
  Exit; [Esc]�@
  (You can change this setting by rewriting "key.conf".)

- System
  Throw your card into the field by push each button [Z]/[X]/[C]/[V].
  If field card at cursor position is...
   [above or below number of thrown card]      Break the field card.
   [NOT above or below number of thrown card]  Swap the field card and thrown card.
   [void]                                      Put thrown card.
  If the cards adjacent broken card are above or below numbers, they are broken too.
  This calls "Chain breaking".
  When certain cards are broken in 1 chain breaking, you get additional bonus.
  [All Black/All Red] 10000pts/5cards, 15000pts/6cards ...
  [Royal Straight] 10000pts
  [Four of a kind] 2-9;20000pts 10-K;30000pts A;50000pts
  [Straight flash] 50000pts/5cards, 60000pts/6cards ...
  [Royal straight flash] 100000pts/5cards, 120000pts/6cards ...
  
- Key configuration
  You can change key setting by rewriting "key.conf" file.
  Fllowing keywords are enable in "key.conf" file.
    0-9, a-z, "-", "^", "@", "[", ",", ".", "/",
    LEFT�CRIGHT�CUP�CDOWN, (arrow keys)
    LSHIFT�CLCTRL�CLALT�CRSHIFT�CRCTRL�CRALT�C
    PAUSE, ESCAPE, BACKSPACE, TAB, RETURN, SPACE, DELETE, INSERT, HOME, END, PAGEUP, PAGEDOWN, 
    KP0-KP9, KP_PERIOD, KP_DIVIDE, KP_MULTIPLY, KP_PLUS, KP_MINUS, KP_ENTER, KP_EQUALS, (numeric keypad keys)
    F1-F15, NUMLOCK, CAPSLOCK, SCROLLOCK

  If you want to set w-s-a-d moving, v-b-n-m droping and SPACE scrolling, rewrite "key.conf" file like this.

#SDLKEYCONF_FILE
#VERSION    1.0
#FREERANGE  0.305204
0; XUP = d
0; XDOWN = a
0; YUP = s
0; YDOWN = w
0; BTN0 = v
0; BTN1 = b
0; BTN2 = n
0; BTN3 = m
0; BTN4 = SPACE
0; ESCAPE = ESCAPE  



