====================================================================
Sky Swimmers' Heaven ver 0.1.2
  Free Soft for Windows 98/me/2000/XP
  Created by Kei Mesuda (HN; keim)
====================================================================

Thank you for downloading this game.
This version is test production.
*****************************************
* THIS SOFTWARE IS NOT REDISTRIBUTABLE. *
* PLEASE WAIT FOR THE PRODUCT VERSION.  *
*****************************************

[ About this game ]
  This is Shotem up game with 'bullet eating system'.
  Only Stage 1 is playable.

[ How to Install ] 
  Unpack zip file. And execute 'sshtest.exe'.

[ How to Uninstall ] 
  Delete all files. This software don't rewrite registry files.

[ Required Environment ]
  OS�G Windows98/2000/XP (Not Tested; Windows95/NT/me)
  CPU; Over PentiumIII 800MHz

[ Copyright ]
  Copyright 2005 Kei Mesuda All rights reserved. 
  I have no responsibility for your trouble with this game and manual.

[ Special Thanks ]
  Simple Directmedia Layer(SDL) is used in this software.
    SDL(Simple Directmedia Layer) http://www.libsdl.org/
  OpenGL is used for 3D calculation.
    OpenGL ARB                    http://www.opengl.org/
  SDL_mixer and Ogg Vorbis CODEC ids used for sound system.
    SDL_mixer 1.2                 http://www.libsdl.org/projects/SDL_mixer/
    Vorbis.com                    http://www.vorbis.com/
    
[ Support ] 
  mail; keim@nona.dti.ne.jp
  web;  http://www.yomogi.sakura.ne.jp/~si/SolidImage/index_e.shtml




//----------------------------------------
// Sky Swimmers' Heaven ver 0.1.2
// Manual
//----------------------------------------
- How to play.
  Play with a Keyboard or Joystick.
  Movement;   Arrow Key
  Shot;       [Z]           = shot1   (Joystick button1)
              [Shift](Left) = shot2   (Joystick button2)
              [X]           = shot1+2 (Joystick button3)
              ([X] key is same as [Z]+[Shift])
  Pause;      [SPACE] (Joystick button4)
  Exit;       [Esc]   (Joystick button5)
  Termination;[F12]
  (You can change this setting by rewriting "key.conf".)

- System
  - EAT System
    When you stay bullets within the blue square field for a certain period of time, 
    The bullets disappeared. This rule is called 'EAT System'.
  - EAT Gauge/ Special weapon
    EAT Gauge (Left-Bottom side of the main screen) is increased by EATing.
    Special weapon is available when EAT Gauge achieve particular level.
    Hold the shot2 button and release, you can shoot the Special weapon.
  - Shot system
    Shot1   Button    = main weapon
    Shot1+2 Button    = sub weapon
    Hold Shot2 Button = special weapon
    (You can exchange sub weapon and special weapon operation.
     [OPTION] -> [CONTROL TYPE] -> [TYPE B])
  - Quick shoot down bonus
    When you shoot down enemy very quickly, you can get additional bonus.
    The shoot down bonus increace twice, and Blue-white bullet is shooted back.
    This Blue-white bullet is EATable bonus item.

- Key configuration
  You can change key setting by rewriting "key.conf" file.
  Fllowing keyword is enable in "key.conf" file.
    0-9, a-z, "-", "^", "@", "[", ",", ".", "/",
    LEFT�CRIGHT�CUP�CDOWN, (arrow keys)
    LSHIFT�CLCTRL�CLALT�CRSHIFT�CRCTRL�CRALT�C
    PAUSE, ESCAPE, BACKSPACE, TAB, RETURN, SPACE, DELETE, INSERT, HOME, END, PAGEUP, PAGEDOWN, 
    KP0-KP9, KP_PERIOD, KP_DIVIDE, KP_MULTIPLY, KP_PLUS, KP_MINUS, KP_ENTER, KP_EQUALS, (numeric keypad keys)
    F1-F15, NUMLOCK, CAPSLOCK, SCROLLOCK

  If you want to set w-s-a-d moving and b-n-m shooting, rewrite "key.conf" file like this.

#SDLKEYCONF_FILE
#VERSION    1.0
#FREERANGE  0.305204
0; XUP = d
0; XDOWN = a
0; YUP = s
0; YDOWN = w
0; BTN0 = b
0; BTN1 = n
0; BTN2 = m
0; BTN3 = ,
0; BTN4 = F12
0; ESCAPE = ESCAPE