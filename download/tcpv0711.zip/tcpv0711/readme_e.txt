====================================================================
TSS Clipboard Player ver 0.4.0
  Free Soft for Windows 98/me/2000/XP
  Created by Kei Mesuda (HN; keim)
====================================================================

Thank you for downloading this apprication.
This apprication is Free-Soft.

The newest version will be download here.
http://www.yomogi.sakura.ne.jp/~si/ 

[ About this game ]
  This is a MML music player. 
  MML music can be played on the clipboard.

[ How to Install ] 
  Unpack zip file. And execute 'tcp.exe'.

[ How to Uninstall ] 
  Delete all files. This software don't rewrite registry files.

[ Required Environment ]
  OS�G WindowsXP (Not Tested; Windows95/98/NT/me/2000)
  CPU; Over Pentium 33MHz

[ Copyright ]
  Copyright 2005 Kei Mesuda All rights reserved. 
  I have no responsibility for your trouble with this application and manual.

[ Special Thanks ]
  Software Synth T'SoundSystem(TSS) is used in this software.
  'nptss.dll' is created by Toyoshima House. 
    Toyoshima House  http://www.toyoshima-house.net/

[ Support ] 
  mail; keim@nona.dti.ne.jp
  web;  http://www.yomogi.sakura.ne.jp/~si/SolidImage/index_e.shtml




//----------------------------------------
// TSS Clipboard Player ver 0.4.0
// Manual
//----------------------------------------
- How to use ?
  Execute this application, and copy MML text.
  This application play the MML data.

  [Execute 'tcp.exe', and copy below text.]
  t150v14%1@3o6q14mp32,16,2,24r1r4$l4/:rdef1l16rrfrgrfreredcr/>ar<d1^4:/dra1^2.r4/
  :l8d4d.c16df4g/l16crdcdc>l8a<cd4r:/l16aragagfdf4l8dfa2l16r<cdc>argra2d4f4a2rrgra
  rg8^4;v13%1@1o4q13mp32,8,2,8r1r4$l4/:rb-<c+d1l16rrdrerdrcrc>aar/frb-1^4:/b-r<d1^
  2.r4>/:l8b-4b-.a16b-<c4d>/l16gragagl8ega4r:/l16<frfefec>aa4l8b-<df2l16rgagfrdrf2
  >b4<d4f2rrerfre8^4;v12%1@3o2l4r1rr$l4/:b-a<d.e.f.d.cc>/b-2^8ag2^8:/l2b-b-<da>/:l
  8gfg^4a<cd^2/dc>a4<:/l4dc>b-.g.a.b-.b2<c2l8rcdc^2;v9%1@2o6q2s24l16r1r1$p1ddp2<d>
  dp1<ddp2<d>d>;v10%2o3l8q2s16l4r1ccrl16))cc(c(c$l4/:/:/:7rc://cc:/l16))crcc(cc(cc
  :/;v5%2o6l16q3s48$c8cc;v7%2o1l8q6s64l8r1r1$crrrccrr
